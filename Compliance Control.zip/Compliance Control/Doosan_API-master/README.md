Python codes for Doosan robot
