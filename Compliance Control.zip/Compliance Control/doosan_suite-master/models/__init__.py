import os

assets_root = os.path.join(os.path.dirname(__file__), "assets")

