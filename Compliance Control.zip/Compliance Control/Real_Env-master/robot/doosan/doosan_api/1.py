

import matplotlib.pyplot as plt
import numpy as np
from pylab import mpl
mpl.rcParams["font.sans-serif"] = ["SimHei"]   # 设置显示中文字体
mpl.rcParams["axes.unicode_minus"] = False   # 设置正常显示符号
plt.style.use('fivethirtyeight')

x = ['东北', '东部', '中部', '西部']
y1 = np.array([6173, 24931, 19901, 24787])
y2 = np.array([1467, 4339, 3978, 5119])
y3 = np.array([446, 1754, 868, 1204])

plt.barh(x, y1, label='一级医疗卫生机构', height=0.67)
plt.barh(x, y2, left=y1, label='二级医疗卫生机构', height=0.67)
plt.barh(x, y3, left=y1+y2, label='三级医疗卫生机构', height=0.67)

plt.xlabel("数量")
plt.ylabel("区域")
plt.title("医疗卫生机构分布")

# 将图例放在右下角X轴之下
plt.legend(loc='lower right', bbox_to_anchor=(1.05, 0))

plt.tight_layout()  # 这可能会重新调整图例的位置，确保它不会超出图表边界
plt.show()

rt_output_data_list = api.read_data_rt()
actual_tcp_position = np.array(rt_output_data_list.actual_tcp_position, dtype=float)
eef_ex_force = np.array(rt_output_data_list.external_tcp_force, dtype=float)

p_acc_norm = np.linalg.norm(eef_ex_force[3:])
# print("p_acc_norm",p_acc_norm)
if p_acc_norm <= 10:
    eef_ex_force = np.zeros_like(eef_ex_force)
delta_RX = delta_X + T * ((eef_ex_force[3] - K1 * delta_X) / B1)
delta_RY = delta_Y + T * ((eef_ex_force[4] - K1 * delta_Y) / B1)
delta_RZ = delta_Z + T * ((eef_ex_force[5] - K1 * delta_Z) / B1)
ro = np.array([delta_RX, delta_RY, delta_RZ])
D_M = R.from_rotvec(ro, degrees=True).as_matrix()
v_1 = np.dot(D_M, mat)
v_1 = R.from_matrix(v_1).as_euler('zyz', degrees=True)
ee = np.concatenate([mov, v_1])
print("ee", ee)
target_vel = np.array([10.0, 10.0, 10, 0, 0, 0], dtype=float)
target_acc = np.array([1, 1, 1, 0, 0, 0], dtype=float)
ee = np.array(ee).tolist()
float_array_type1 = ctypes.c_float * 6
pos = float_array_type1(*ee)
float_array_type2 = ctypes.c_float * 6
target_vel = float_array_type2(*target_vel)
float_array_type3 = ctypes.c_float * 6
target_acc = float_array_type3(*target_acc)
# api.servol_rt(pos,target_vel,target_acc,0.2)
end = time.time()
i = i + 1
print(i)
time.sleep(0.01)





'''
import matplotlib.pyplot as plt

from pylab import mpl
mpl.rcParams["font.sans-serif"] = ["SimHei"]   # 设置显示中文字体
mpl.rcParams["axes.unicode_minus"] = False   # 设置正常显示符号
import matplotlib.pyplot as plt
import numpy as np

plt.style.use('fivethirtyeight')

x = ['东北', '东部', '中部', '西部']
y1 = np.array([6173, 24931, 19901, 24787])
y2 = np.array([1467, 4339, 3978, 5119])
y3 = np.array([446, 1754, 868, 1204])

plt.barh(x, y1, label='一级', height=0.67)
plt.barh(x, y2, left=y1, label='二级', height=0.67)
plt.barh(x, y3, left=y1 + y2, label='三级', height=0.67)

plt.xlabel("数量")
plt.ylabel("区域")
plt.legend()
plt.title("医疗卫生机构分布")

plt.tight_layout()
plt.show()
'''